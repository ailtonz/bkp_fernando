﻿using ProductsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ProductsApp.Controllers
{
    public class ProductsController : ApiController
    {
        private Business.Product businessProducts;

        public ProductsController()
        {
            businessProducts = new Business.Product();
        }
        

        public IEnumerable<Product> GetAllProducts()
        {
            return businessProducts.Listar();
        }

        //public IHttpActionResult GetProduct(int id)
        //{
        //    var product = products.FirstOrDefault((p) => p.id == id);
        //    if (product == null)
        //    {
        //        return NotFound();
        //    }
        //    return Ok(product);
        //}

        [HttpPut]
        public IHttpActionResult InsertProduct(Product prd)
        {

            //if (DB.add(prd))
            //    return Ok(prd);
            //else
                return null;
        }

        [HttpPost]
        public IHttpActionResult UpdateProduct(Product prd)
        {

            //if (DB.add(prd))
            //    return Ok(prd);
            //else
                return null;
        }


        [HttpDelete]
        public IHttpActionResult DeleteProduct(Product prd)
        {

            //if (DB.add(prd))
            //    return Ok(prd);
            //else
                return null;
        }




    }
}
