﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductsApp.Data
{
    public class Products
    {
        public List<ProductsApp.Models.Product> Listar()
        {
            using (ProductsApp.DB.DB_AILTONEntities context = new DB.DB_AILTONEntities())
            {
                return context.TB_CATEGORIA.Select(s => new Models.Product
                {
                    id = s.ID_CATEGORIA
                }).ToList();
            }
        }

        public List<ProductsApp.Models.Product> Insert(Models.Product prd)
        {
            using (ProductsApp.DB.DB_AILTONEntities context = new DB.DB_AILTONEntities())
            {
                return context.TB_CATEGORIA.Select(s => new Models.Product
                {
                    id = Convert.ToInt32(s.ID_CATEGORIA)
                }).ToList();
            }
        }

        public List<ProductsApp.Models.Product> Update(Models.Product prd)
        {
            using (ProductsApp.DB.DB_AILTONEntities context = new DB.DB_AILTONEntities())
            {
                return context.TB_CATEGORIA.Select(s => new Models.Product
                {
                    id = Convert.ToInt32(s.ID_CATEGORIA)
                }).ToList();
            }
        }

        public List<ProductsApp.Models.Product> Delete(long id)
        {
            using (ProductsApp.DB.DB_AILTONEntities context = new DB.DB_AILTONEntities())
            {
                return context.TB_CATEGORIA.Select(s => new Models.Product
                {
                    id = Convert.ToInt32(s.ID_CATEGORIA)
                }).ToList();
            }
        }
    }
}
