﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductsApp.Business
{
    public class Product
    {
        private Data.Products dataProducts;

        public Product()
        {
            dataProducts = new Data.Products();
        }

        public List<ProductsApp.Models.Product> Listar()
        {
            if (true)
            {
                return dataProducts.Listar();
            }


            
        }
    }
}
