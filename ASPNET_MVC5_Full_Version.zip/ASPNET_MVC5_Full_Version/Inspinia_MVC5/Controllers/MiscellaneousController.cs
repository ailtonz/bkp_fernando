﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Inspinia_MVC5.Controllers
{
    public class MiscellaneousController : Controller
    {

        public ActionResult GoogleMaps()
        {
            return View();
        }

        public ActionResult CodeEditor()
        {
            return View();
        }

        public ActionResult ModalWindow()
        {
            return View();
        }

        public ActionResult NestableList()
        {
            return View();
        }

        public ActionResult Validation()
        {
            return View();
        }

        public ActionResult Notification()
        {
            return View();
        }

        public ActionResult Timeline_second_version()
        {
            return View();
        }

        public ActionResult Forum_view()
        {
            return View();
        }

        public ActionResult Forum_post_view()
        {
            return View();
        }

        public ActionResult Tree_view()
        {
            return View();
        }

        public ActionResult Chat_view()
        {
            return View();
        }

        public ActionResult AgileBoard()
        {
            return View();
        }

        public ActionResult Diff()
        {
            return View();
        }

        public ActionResult SweetAlert()
        {
            return View();
        }

        public ActionResult IdleTimer()
        {
            return View();
        }

        public ActionResult Spinners()
        {
            return View();
        }

        public ActionResult SpinnersUsage()
        {
            return View();
        }

        public ActionResult LiveFavicon()
        {
            return View();
        }

        public ActionResult Masonry()
        {
            return View();
        }

        public ActionResult LoadingButtons()
        {
            return View();
        }

        public ActionResult I18support()
        {
            return View();
        }

        public ActionResult Truncate()
        {
            return View();
        }

        public ActionResult PasswordMeter()
        {
            return View();
        }

        public ActionResult Clipboard()
        {
            return View();
        }

        public ActionResult TextSpinners()
        {
            return View();
        }

        public ActionResult Tour()
        {
            return View();
        }

        public ActionResult Datamaps()
        {
            return View();
        }

        public ActionResult PdfViewer()
        {
            return View();
        }

        public ActionResult SocialButtons()
        {
            return View();
        }
    }
}